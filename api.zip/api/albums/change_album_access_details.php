<?php
// required headers
require_once '../config/cors_headers.php';
// include database and object files
require_once '../objects/albums.php';

// initialize object
$albums = new Albums();
 
// products array
$postData = json_decode(file_get_contents("php://input"));
$result_arr=array();
$result_arr["records"]=$albums->changeAlbumAccessDetails($postData);
 
// check if more than 0 record found
if(count($result_arr["records"]) == true){
 
	$result_arr["status"]='Success';
	$result_arr["message"]= 'Access Settings Updated Succefully';
    // set response code - 200 OK
    http_response_code(200);
 
    // make it json format
    echo json_encode($result_arr);
}
 
else{
	$result_arr["status"]='Failed';
	$result_arr["message"]='Failed to update Access Settings';
    // set response code - 404 Not found
    http_response_code(404);
 
    // tell the user products does not exist
    echo json_encode($result_arr);
}
?>