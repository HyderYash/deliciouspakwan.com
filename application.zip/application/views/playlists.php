<main>
	<!-- Display Slider card -- PLAYLISTS --  Start here -->
		<?=displaySliderCardForPlaylist($listOfPlaylist)?>
	<!-- Display Slider card -- PLAYLISTS --  End here -->
</main>
<div style="margin-top:30px;">&nbsp;</div>
