<?php
for($i = 0; $i < count($tmpArray); $i++){

	print ($i+1)  . ' ===> ' . $tmpArray[$i];
	print "<br>=======+++++++++++++++++++++++=================<br>";
}					
?>