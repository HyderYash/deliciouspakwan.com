<main>
	<!-- Display Slider card -- Recent Videos --  Start here -->
		<?=displaySliderCardForRecentVideos($recentVideos)?>
	<!-- Display Slider card -- Recent Videos --  End here -->
	
	<!-- Google ads will display here -->
		<!--div class="ads-main-container">
			<div class="ads-size-horizontal-big">
			Yash<br>

			</div>
		</div-->
	<!-- Google ads will display here -->
	
	<section class="container mobileclass">
		<div class="site-content">
			<div class="posts extra-top-mar">
				<?=_getCategoryHeading('Watch Top Videos Here')?>
				<?php
				foreach($midAgedVideos as $rec){	
					echo displayBigZoominCards('no',$rec);
				}
				?>					
			</div>
			<aside class="sidebar">
				<div class="category">
					<?=_getCategoryHeading('Our Top Playlists', 'small')?>
					<ul class="category-list">
						<?php
						if(is_array($listOfPlaylist) && count($listOfPlaylist) > 0) {
							echo _getListOfPlaylists($listOfPlaylist);
						}
						?>
					</ul>
				</div>
				<div class="popular-post" id="showVideos">
					<?=_getCategoryHeading('Our Popular Videos', 'small')?>
					<?php
					foreach($mostViewedRandomVideos as $rec){
						echo popularVideosSideBar($rec);
					}
					?>
				</div>
			</aside>
		</div>
	</section>
</main>
